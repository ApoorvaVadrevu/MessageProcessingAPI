package messageProcessingAPI;

class Sale{
	private String productType;
	private double value;
	private int numOfSales;
	
	Sale(String productType, double value, int numOfSales){
		this.productType = productType;
		this.value = value;
		this.numOfSales = numOfSales;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}
	
	public void setNumOfSales(int numOfSales){
		this.numOfSales = numOfSales;
	}
	public int getNumOfSales(){
		return numOfSales;
	}
}
