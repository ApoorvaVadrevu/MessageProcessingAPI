package messageProcessingAPI;

class SaleSummary{
	private String productType;
	private double totalValue;
	private int totalNumOfSales;
	
	public SaleSummary(String productType, double totalValue, int totalNumOfSales) {
		super();
		this.productType = productType;
		this.totalValue = totalValue;
		this.totalNumOfSales = totalNumOfSales;
	}
	
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public double getTotalValue() {
		return totalValue;
	}
	public void setTotalValue(double totalValue) {
		this.totalValue = totalValue;
	}
	public int getTotalNumOfSales() {
		return totalNumOfSales;
	}
	public void setTotalNumOfSales(int totalNumOfSales) {
		this.totalNumOfSales = totalNumOfSales;
	}
	
}
