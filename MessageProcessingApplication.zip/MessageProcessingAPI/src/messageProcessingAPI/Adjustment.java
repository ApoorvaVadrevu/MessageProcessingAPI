package messageProcessingAPI;

class Adjustment{
	private String productType;
	private String action;
	private double valueToPerformAction;
	
	public Adjustment(String productType, String action, double valueToPerformAction) {
		this.productType = productType;
		this.action = action;
		this.valueToPerformAction = valueToPerformAction;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public double getValueToPerformAction() {
		return valueToPerformAction;
	}
	public void setValueToPerformAction(double valueToPerformAction) {
		this.valueToPerformAction = valueToPerformAction;
	}
}

